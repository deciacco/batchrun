using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BatchRun
{
	public partial class RunScripts : Form
	{
		public RunScripts()
		{
			InitializeComponent();
		}
		
		private void RunScripts_Shown(object sender, EventArgs e)
		{
			this.executeScripts();
		}
		
		private void executeScripts()
		{
			CheckedListBox checkedListBoxScriptFiles = (CheckedListBox)this.Owner.Controls["checkedListBoxScriptFiles"];
			
			// Set the view to show details.
			listView1.View = View.Details;
			// Select the item and subitems when selection is made.
			listView1.FullRowSelect = true;
			// Sort the items in the list in ascending order.
			listView1.Sorting = SortOrder.Ascending;

			// Create columns for the items and subitems.
			listView1.Columns.Add("Script Execution Status...", -2, HorizontalAlignment.Left);
			
			for (int i = 0; i < checkedListBoxScriptFiles.CheckedItems.Count; i++)
			{
				ListViewItem li = new ListViewItem(checkedListBoxScriptFiles.CheckedItems[i].ToString(), i);
				this.listView1.Items.Add(li);
			}
		}
	}
}