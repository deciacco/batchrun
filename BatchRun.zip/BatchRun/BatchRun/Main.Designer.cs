namespace BatchRun
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
			this.buttonBrowse = new System.Windows.Forms.Button();
			this.textBoxScriptsFolder = new System.Windows.Forms.TextBox();
			this.textBoxSqlConnString = new System.Windows.Forms.TextBox();
			this.folderBrowserDialogScripts = new System.Windows.Forms.FolderBrowserDialog();
			this.buttonRun = new System.Windows.Forms.Button();
			this.menuStripMain = new System.Windows.Forms.MenuStrip();
			this.tsmFile = new System.Windows.Forms.ToolStripMenuItem();
			this.tsmExit = new System.Windows.Forms.ToolStripMenuItem();
			this.tsmAbout = new System.Windows.Forms.ToolStripMenuItem();
			this.tsmHelp = new System.Windows.Forms.ToolStripMenuItem();
			this.labelConnString = new System.Windows.Forms.Label();
			this.buttonBuildConnString = new System.Windows.Forms.Button();
			this.labelScriptsFolder = new System.Windows.Forms.Label();
			this.labelFoundSqlScriptFiles = new System.Windows.Forms.Label();
			this.buttonMoveItemUp = new System.Windows.Forms.Button();
			this.buttonMoveItemDown = new System.Windows.Forms.Button();
			this.checkedListBoxScriptFiles = new System.Windows.Forms.CheckedListBox();
			this.toolTip = new System.Windows.Forms.ToolTip(this.components);
			this.menuStripMain.SuspendLayout();
			this.SuspendLayout();
			// 
			// buttonBrowse
			// 
			this.buttonBrowse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonBrowse.Location = new System.Drawing.Point(384, 106);
			this.buttonBrowse.Name = "buttonBrowse";
			this.buttonBrowse.Size = new System.Drawing.Size(75, 23);
			this.buttonBrowse.TabIndex = 1;
			this.buttonBrowse.Text = "B&rowse...";
			this.buttonBrowse.UseVisualStyleBackColor = true;
			this.buttonBrowse.Click += new System.EventHandler(this.buttonBrowse_Click);
			// 
			// textBoxScriptsFolder
			// 
			this.textBoxScriptsFolder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxScriptsFolder.Location = new System.Drawing.Point(12, 108);
			this.textBoxScriptsFolder.Name = "textBoxScriptsFolder";
			this.textBoxScriptsFolder.ReadOnly = true;
			this.textBoxScriptsFolder.Size = new System.Drawing.Size(366, 20);
			this.textBoxScriptsFolder.TabIndex = 0;
			this.textBoxScriptsFolder.TabStop = false;
			this.toolTip.SetToolTip(this.textBoxScriptsFolder, "Folder where *.sql files are located.");
			// 
			// textBoxSqlConnString
			// 
			this.textBoxSqlConnString.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxSqlConnString.Location = new System.Drawing.Point(12, 52);
			this.textBoxSqlConnString.Multiline = true;
			this.textBoxSqlConnString.Name = "textBoxSqlConnString";
			this.textBoxSqlConnString.ReadOnly = true;
			this.textBoxSqlConnString.Size = new System.Drawing.Size(366, 37);
			this.textBoxSqlConnString.TabIndex = 2;
			this.textBoxSqlConnString.TabStop = false;
			this.toolTip.SetToolTip(this.textBoxSqlConnString, "Connection string to SQL Server. Use the Build... button\r\nto create it.");
			// 
			// buttonRun
			// 
			this.buttonRun.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.buttonRun.Location = new System.Drawing.Point(384, 331);
			this.buttonRun.Name = "buttonRun";
			this.buttonRun.Size = new System.Drawing.Size(75, 23);
			this.buttonRun.TabIndex = 5;
			this.buttonRun.Text = "&Run Scripts";
			this.buttonRun.UseVisualStyleBackColor = true;
			this.buttonRun.Click += new System.EventHandler(this.buttonRun_Click);
			// 
			// menuStripMain
			// 
			this.menuStripMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmFile,
            this.tsmAbout,
            this.tsmHelp});
			this.menuStripMain.Location = new System.Drawing.Point(0, 0);
			this.menuStripMain.Name = "menuStripMain";
			this.menuStripMain.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
			this.menuStripMain.Size = new System.Drawing.Size(471, 24);
			this.menuStripMain.TabIndex = 6;
			this.menuStripMain.Text = "menuStripMain";
			// 
			// tsmFile
			// 
			this.tsmFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmExit});
			this.tsmFile.Name = "tsmFile";
			this.tsmFile.Size = new System.Drawing.Size(35, 20);
			this.tsmFile.Text = "&File";
			// 
			// tsmExit
			// 
			this.tsmExit.Name = "tsmExit";
			this.tsmExit.Size = new System.Drawing.Size(152, 22);
			this.tsmExit.Text = "E&xit";
			this.tsmExit.Click += new System.EventHandler(this.tsmExit_Click);
			// 
			// tsmAbout
			// 
			this.tsmAbout.Name = "tsmAbout";
			this.tsmAbout.Size = new System.Drawing.Size(48, 20);
			this.tsmAbout.Text = "&About";
			this.tsmAbout.Click += new System.EventHandler(this.tsmAbout_Click);
			// 
			// tsmHelp
			// 
			this.tsmHelp.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
			this.tsmHelp.Name = "tsmHelp";
			this.tsmHelp.Size = new System.Drawing.Size(40, 20);
			this.tsmHelp.Text = "&Help";
			// 
			// labelConnString
			// 
			this.labelConnString.AutoSize = true;
			this.labelConnString.Location = new System.Drawing.Point(12, 36);
			this.labelConnString.Name = "labelConnString";
			this.labelConnString.Size = new System.Drawing.Size(91, 13);
			this.labelConnString.TabIndex = 8;
			this.labelConnString.Text = "Connection String";
			// 
			// buttonBuildConnString
			// 
			this.buttonBuildConnString.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonBuildConnString.Location = new System.Drawing.Point(384, 50);
			this.buttonBuildConnString.Name = "buttonBuildConnString";
			this.buttonBuildConnString.Size = new System.Drawing.Size(75, 23);
			this.buttonBuildConnString.TabIndex = 0;
			this.buttonBuildConnString.Text = "&Build...";
			this.buttonBuildConnString.UseVisualStyleBackColor = true;
			this.buttonBuildConnString.Click += new System.EventHandler(this.buttonBuildConnString_Click);
			// 
			// labelScriptsFolder
			// 
			this.labelScriptsFolder.AutoSize = true;
			this.labelScriptsFolder.Location = new System.Drawing.Point(12, 92);
			this.labelScriptsFolder.Name = "labelScriptsFolder";
			this.labelScriptsFolder.Size = new System.Drawing.Size(71, 13);
			this.labelScriptsFolder.TabIndex = 10;
			this.labelScriptsFolder.Text = "Scripts Folder";
			// 
			// labelFoundSqlScriptFiles
			// 
			this.labelFoundSqlScriptFiles.AutoSize = true;
			this.labelFoundSqlScriptFiles.Location = new System.Drawing.Point(12, 131);
			this.labelFoundSqlScriptFiles.Name = "labelFoundSqlScriptFiles";
			this.labelFoundSqlScriptFiles.Size = new System.Drawing.Size(109, 13);
			this.labelFoundSqlScriptFiles.TabIndex = 11;
			this.labelFoundSqlScriptFiles.Text = "Found Sql Script Files";
			// 
			// buttonMoveItemUp
			// 
			this.buttonMoveItemUp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonMoveItemUp.Font = new System.Drawing.Font("Wingdings", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
			this.buttonMoveItemUp.Location = new System.Drawing.Point(433, 147);
			this.buttonMoveItemUp.Name = "buttonMoveItemUp";
			this.buttonMoveItemUp.Size = new System.Drawing.Size(26, 23);
			this.buttonMoveItemUp.TabIndex = 3;
			this.buttonMoveItemUp.Text = "�";
			this.buttonMoveItemUp.UseVisualStyleBackColor = true;
			this.buttonMoveItemUp.Click += new System.EventHandler(this.buttonMoveItemUp_Click);
			// 
			// buttonMoveItemDown
			// 
			this.buttonMoveItemDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonMoveItemDown.Font = new System.Drawing.Font("Wingdings", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
			this.buttonMoveItemDown.Location = new System.Drawing.Point(433, 176);
			this.buttonMoveItemDown.Name = "buttonMoveItemDown";
			this.buttonMoveItemDown.Size = new System.Drawing.Size(26, 23);
			this.buttonMoveItemDown.TabIndex = 4;
			this.buttonMoveItemDown.Text = "�";
			this.buttonMoveItemDown.UseVisualStyleBackColor = true;
			this.buttonMoveItemDown.Click += new System.EventHandler(this.buttonMoveItemDown_Click);
			// 
			// checkedListBoxScriptFiles
			// 
			this.checkedListBoxScriptFiles.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.checkedListBoxScriptFiles.FormattingEnabled = true;
			this.checkedListBoxScriptFiles.Location = new System.Drawing.Point(12, 147);
			this.checkedListBoxScriptFiles.Name = "checkedListBoxScriptFiles";
			this.checkedListBoxScriptFiles.Size = new System.Drawing.Size(415, 169);
			this.checkedListBoxScriptFiles.TabIndex = 2;
			this.toolTip.SetToolTip(this.checkedListBoxScriptFiles, "List of .sql script files to execute. \r\nUse the errows to the right to change\r\nth" +
					"e order in which they get sent to the\r\nserver.");
			// 
			// toolTip
			// 
			this.toolTip.AutomaticDelay = 200;
			this.toolTip.UseAnimation = false;
			this.toolTip.UseFading = false;
			// 
			// Main
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(471, 366);
			this.Controls.Add(this.checkedListBoxScriptFiles);
			this.Controls.Add(this.buttonMoveItemDown);
			this.Controls.Add(this.buttonMoveItemUp);
			this.Controls.Add(this.labelFoundSqlScriptFiles);
			this.Controls.Add(this.labelScriptsFolder);
			this.Controls.Add(this.buttonBuildConnString);
			this.Controls.Add(this.labelConnString);
			this.Controls.Add(this.buttonRun);
			this.Controls.Add(this.textBoxSqlConnString);
			this.Controls.Add(this.textBoxScriptsFolder);
			this.Controls.Add(this.buttonBrowse);
			this.Controls.Add(this.menuStripMain);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MainMenuStrip = this.menuStripMain;
			this.MaximizeBox = false;
			this.MaximumSize = new System.Drawing.Size(479, 800);
			this.MinimumSize = new System.Drawing.Size(479, 400);
			this.Name = "Main";
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Batch Run v1.0 Dev";
			this.menuStripMain.ResumeLayout(false);
			this.menuStripMain.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

		private System.Windows.Forms.Button buttonBrowse;
        private System.Windows.Forms.TextBox textBoxScriptsFolder;
        private System.Windows.Forms.TextBox textBoxSqlConnString;
		private System.Windows.Forms.FolderBrowserDialog folderBrowserDialogScripts;
		private System.Windows.Forms.Button buttonRun;
		private System.Windows.Forms.MenuStrip menuStripMain;
		private System.Windows.Forms.ToolStripMenuItem tsmFile;
		private System.Windows.Forms.ToolStripMenuItem tsmExit;
		private System.Windows.Forms.ToolStripMenuItem tsmAbout;
		private System.Windows.Forms.Label labelConnString;
		private System.Windows.Forms.Button buttonBuildConnString;
		private System.Windows.Forms.Label labelScriptsFolder;
		private System.Windows.Forms.Label labelFoundSqlScriptFiles;
		private System.Windows.Forms.Button buttonMoveItemUp;
		private System.Windows.Forms.Button buttonMoveItemDown;
		private System.Windows.Forms.CheckedListBox checkedListBoxScriptFiles;
		private System.Windows.Forms.ToolTip toolTip;
		private System.Windows.Forms.ToolStripMenuItem tsmHelp;
    }
}