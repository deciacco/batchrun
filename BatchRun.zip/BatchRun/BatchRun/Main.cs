using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BatchRun
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }
        
		private void populateScriptsList()
        {
			DirectoryInfo dinfo;

			try
			{

				if (this.textBoxScriptsFolder.Text == string.Empty)
					MessageBox.Show(this, @"Please select a scripts folder.");
				else
				{
					dinfo = new DirectoryInfo(this.textBoxScriptsFolder.Text);
					foreach (FileInfo f in dinfo.GetFiles())
					{
						if (f.Extension.ToLower() == @".sql")
							this.checkedListBoxScriptFiles.Items.Add(f.Name, true);
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}
        }
		private string getConnString(string inputStr)
		{
			string tmpReturn = string.Empty;

			MSDASC.DataLinks dataLinks = new MSDASC.DataLinksClass();
			ADODB._Connection connection;

			if (inputStr == String.Empty)
			{     
				try   
				{           
					connection = (ADODB._Connection)dataLinks.PromptNew();
					if (connection != null)//if cancel is pressed connection is null
						tmpReturn = connection.ConnectionString;
				}
				catch(Exception ex)     
				{
					  MessageBox.Show(ex.ToString());     
				}
			}
			else
			{
				connection=new ADODB.ConnectionClass();
				connection.ConnectionString = inputStr;
				
				object oConnection=connection;
				try   
				{     	  
					if((bool)dataLinks.PromptEdit(ref oConnection))
					{
						tmpReturn = connection.ConnectionString;
					}
				}
				catch(Exception ex)
				{
					MessageBox.Show(ex.ToString());     
				}
			}
			return tmpReturn;
		}
		
		private void buttonBrowse_Click(object sender, EventArgs e)
		{
			this.folderBrowserDialogScripts.ShowNewFolderButton = false;
			this.folderBrowserDialogScripts.RootFolder = Environment.SpecialFolder.DesktopDirectory;
			this.folderBrowserDialogScripts.ShowDialog(this);
			this.textBoxScriptsFolder.Text = this.folderBrowserDialogScripts.SelectedPath;
			
			if(this.textBoxScriptsFolder.Text != string.Empty)
				this.populateScriptsList();
		}
		private void tsmConnStringBuilder_Click(object sender, EventArgs e)
		{
			this.textBoxSqlConnString.Text = this.getConnString(this.textBoxSqlConnString.Text);
		}
		private void tsmAbout_Click(object sender, EventArgs e)
		{
			AboutBox frmAbout = new AboutBox();
			frmAbout.ShowDialog(this);
		}
		private void buttonBuildConnString_Click(object sender, EventArgs e)
		{
			this.textBoxSqlConnString.Text = this.getConnString(this.textBoxSqlConnString.Text);
		}
		private void tsmExit_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}
		private void buttonMoveItemUp_Click(object sender, EventArgs e)
		{
			if (this.checkedListBoxScriptFiles.Items.Count > 0 && this.checkedListBoxScriptFiles.SelectedIndex > -1)
			{
				int selectedIndex;
				CheckState selectedCheckedState;
				object selectedItem;

				selectedIndex = this.checkedListBoxScriptFiles.SelectedIndex;
				selectedItem = this.checkedListBoxScriptFiles.SelectedItem;
				selectedCheckedState = this.checkedListBoxScriptFiles.GetItemCheckState(selectedIndex);

				this.checkedListBoxScriptFiles.Items.Remove(this.checkedListBoxScriptFiles.Items[selectedIndex]);

				if (selectedIndex == 0)
					selectedIndex = this.checkedListBoxScriptFiles.Items.Count + 1;

				this.checkedListBoxScriptFiles.Items.Insert(selectedIndex - 1, selectedItem);
				this.checkedListBoxScriptFiles.SelectedIndex = selectedIndex - 1;
				this.checkedListBoxScriptFiles.SetItemCheckState(selectedIndex - 1, selectedCheckedState);
			}
		}
		private void buttonMoveItemDown_Click(object sender, EventArgs e)
		{
			if (this.checkedListBoxScriptFiles.Items.Count > 0 && this.checkedListBoxScriptFiles.SelectedIndex > -1)
			{
				int selectedIndex;
				CheckState selectedCheckedState;
				object selectedItem;

				selectedIndex = this.checkedListBoxScriptFiles.SelectedIndex;
				selectedItem = this.checkedListBoxScriptFiles.SelectedItem;
				selectedCheckedState = this.checkedListBoxScriptFiles.GetItemCheckState(selectedIndex);

				this.checkedListBoxScriptFiles.Items.Remove(this.checkedListBoxScriptFiles.Items[selectedIndex]);

				if (selectedIndex == this.checkedListBoxScriptFiles.Items.Count)
					selectedIndex = -1;

				this.checkedListBoxScriptFiles.Items.Insert(selectedIndex + 1, selectedItem);
				this.checkedListBoxScriptFiles.SelectedIndex = selectedIndex + 1;
				this.checkedListBoxScriptFiles.SetItemCheckState(selectedIndex + 1, selectedCheckedState);
			}
		}
		private void tsmSave_Click(object sender, EventArgs e)
		{
		}

		private void buttonRun_Click(object sender, EventArgs e)
		{
			RunScripts frmRunScripts = new RunScripts();
			frmRunScripts.ShowDialog(this);
		}
    }
}